import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.datatransfer.StringSelection;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Random;

public class RSACipherGUI {
    private JFrame frame;
    private JTextField pField, qField, eField, nField, dField, messageField, encryptedField;
    private JTextArea outputArea;
    private JButton generateButton, encryptButton, decryptButton, useLastButton, clearButton;
    private JRadioButton useLastYes, useLastNo;
    private ButtonGroup lastGroup;

    private BigInteger p, q, n, phi, e, d;
    private ArrayList<BigInteger> lastEncrypted = new ArrayList<>();
    private boolean hasLastEncrypted = false;
    private static final BigInteger MIN_E = BigInteger.valueOf(2);

    private Color primaryBg = new Color(255, 240, 245);
    private Color secondaryBg = new Color(255, 228, 236);
    private Color buttonColor = new Color(255, 209, 220);
    private Color borderColor = new Color(255, 182, 193);
    private Color textColor = new Color(80, 40, 50);
    private Color fieldBg = new Color(255, 250, 250);

    public RSACipherGUI() {
        createGUI();
    }

    private void createGUI() {
        frame = new JFrame("RSA Шифрование (Вариант: p=223, q=317)");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(850, 700);
        frame.setLayout(new BorderLayout(10, 10));
        frame.getContentPane().setBackground(primaryBg);

        JPanel mainPanel = new JPanel(new GridBagLayout());
        mainPanel.setBackground(primaryBg);
        mainPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        int row = 0;

        JLabel titleLabel = new JLabel("RSA Шифрование", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        titleLabel.setForeground(new Color(150, 80, 100));
        gbc.gridx = 0; gbc.gridy = row; gbc.gridwidth = 2;
        mainPanel.add(titleLabel, gbc);

        row++;
        gbc.gridx = 0; gbc.gridy = row; gbc.gridwidth = 1;
        JLabel pLabel = new JLabel("Первое простое число (p):");
        pLabel.setForeground(textColor);
        pLabel.setFont(new Font("Arial", Font.BOLD, 12));
        mainPanel.add(pLabel, gbc);

        gbc.gridx = 1;
        pField = new JTextField(15);
        pField.setText("223");
        pField.setBackground(fieldBg);
        pField.setForeground(textColor);
        pField.setBorder(new LineBorder(borderColor, 2, true));
        mainPanel.add(pField, gbc);

        row++;
        gbc.gridx = 0; gbc.gridy = row;
        JLabel qLabel = new JLabel("Второе простое число (q):");
        qLabel.setForeground(textColor);
        qLabel.setFont(new Font("Arial", Font.BOLD, 12));
        mainPanel.add(qLabel, gbc);

        gbc.gridx = 1;
        qField = new JTextField(15);
        qField.setText("317");
        qField.setBackground(fieldBg);
        qField.setForeground(textColor);
        qField.setBorder(new LineBorder(borderColor, 2, true));
        mainPanel.add(qField, gbc);

        row++;
        gbc.gridx = 0; gbc.gridy = row; gbc.gridwidth = 2;
        generateButton = new JButton("Сгенерировать ключи");
        generateButton.setBackground(buttonColor);
        generateButton.setForeground(textColor);
        generateButton.setFont(new Font("Arial", Font.BOLD, 12));
        generateButton.setBorder(new LineBorder(borderColor, 2, true));
        generateButton.setFocusPainted(false);
        generateButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        mainPanel.add(generateButton, gbc);

        row++;
        gbc.gridx = 0; gbc.gridy = row; gbc.gridwidth = 1;
        JLabel publicLabel = new JLabel("Открытый ключ (e, n):");
        publicLabel.setForeground(textColor);
        publicLabel.setFont(new Font("Arial", Font.BOLD, 12));
        mainPanel.add(publicLabel, gbc);

        gbc.gridx = 1;
        JPanel keyPanel = new JPanel(new GridLayout(1, 2, 5, 0));
        keyPanel.setBackground(primaryBg);

        eField = new JTextField();
        eField.setEditable(false);
        eField.setBackground(secondaryBg);
        eField.setForeground(textColor);
        eField.setBorder(new LineBorder(borderColor, 2, true));

        nField = new JTextField();
        nField.setEditable(false);
        nField.setBackground(secondaryBg);
        nField.setForeground(textColor);
        nField.setBorder(new LineBorder(borderColor, 2, true));

        keyPanel.add(eField);
        keyPanel.add(nField);
        mainPanel.add(keyPanel, gbc);

        row++;
        gbc.gridx = 0; gbc.gridy = row;
        JLabel privateLabel = new JLabel("Закрытый ключ (d, n):");
        privateLabel.setForeground(textColor);
        privateLabel.setFont(new Font("Arial", Font.BOLD, 12));
        mainPanel.add(privateLabel, gbc);

        gbc.gridx = 1;
        JPanel privateKeyPanel = new JPanel(new GridLayout(1, 2, 5, 0));
        privateKeyPanel.setBackground(primaryBg);

        dField = new JTextField();
        dField.setEditable(false);
        dField.setBackground(secondaryBg);
        dField.setForeground(textColor);
        dField.setBorder(new LineBorder(borderColor, 2, true));

        JTextField nField2 = new JTextField();
        nField2.setEditable(false);
        nField2.setEnabled(false);
        nField2.setBackground(secondaryBg);
        nField2.setForeground(textColor);
        nField2.setBorder(new LineBorder(borderColor, 2, true));

        privateKeyPanel.add(dField);
        privateKeyPanel.add(nField2);
        mainPanel.add(privateKeyPanel, gbc);

        row++;
        gbc.gridx = 0; gbc.gridy = row;
        JLabel messageLabel = new JLabel("Сообщение для шифрования:");
        messageLabel.setForeground(textColor);
        messageLabel.setFont(new Font("Arial", Font.BOLD, 12));
        mainPanel.add(messageLabel, gbc);

        gbc.gridx = 1;
        messageField = new JTextField(30);
        messageField.setBackground(fieldBg);
        messageField.setForeground(textColor);
        messageField.setBorder(new LineBorder(borderColor, 2, true));
        mainPanel.add(messageField, gbc);

        row++;
        gbc.gridx = 0; gbc.gridy = row; gbc.gridwidth = 2;
        JPanel actionPanel = new JPanel(new FlowLayout());
        actionPanel.setBackground(primaryBg);

        encryptButton = new JButton("1. Зашифровать");
        encryptButton.setBackground(buttonColor);
        encryptButton.setForeground(textColor);
        encryptButton.setFont(new Font("Arial", Font.BOLD, 12));
        encryptButton.setBorder(new LineBorder(borderColor, 2, true));
        encryptButton.setFocusPainted(false);
        encryptButton.setCursor(new Cursor(Cursor.HAND_CURSOR));

        decryptButton = new JButton("2. Расшифровать");
        decryptButton.setBackground(buttonColor);
        decryptButton.setForeground(textColor);
        decryptButton.setFont(new Font("Arial", Font.BOLD, 12));
        decryptButton.setBorder(new LineBorder(borderColor, 2, true));
        decryptButton.setFocusPainted(false);
        decryptButton.setCursor(new Cursor(Cursor.HAND_CURSOR));

        actionPanel.add(encryptButton);
        actionPanel.add(decryptButton);
        mainPanel.add(actionPanel, gbc);

        row++;
        gbc.gridx = 0; gbc.gridy = row; gbc.gridwidth = 2;
        JPanel lastPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        lastPanel.setBackground(primaryBg);

        JLabel lastLabel = new JLabel("Использовать последнее сообщение?");
        lastLabel.setForeground(textColor);
        lastLabel.setFont(new Font("Arial", Font.BOLD, 12));

        useLastYes = new JRadioButton("да");
        useLastYes.setBackground(primaryBg);
        useLastYes.setForeground(textColor);
        useLastYes.setFont(new Font("Arial", Font.PLAIN, 12));

        useLastNo = new JRadioButton("нет");
        useLastNo.setBackground(primaryBg);
        useLastNo.setForeground(textColor);
        useLastNo.setFont(new Font("Arial", Font.PLAIN, 12));
        useLastNo.setSelected(true);

        lastGroup = new ButtonGroup();
        lastGroup.add(useLastYes);
        lastGroup.add(useLastNo);

        useLastButton = new JButton("Применить выбор");
        useLastButton.setBackground(buttonColor);
        useLastButton.setForeground(textColor);
        useLastButton.setFont(new Font("Arial", Font.BOLD, 12));
        useLastButton.setBorder(new LineBorder(borderColor, 2, true));
        useLastButton.setFocusPainted(false);
        useLastButton.setCursor(new Cursor(Cursor.HAND_CURSOR));

        lastPanel.add(lastLabel);
        lastPanel.add(useLastYes);
        lastPanel.add(useLastNo);
        lastPanel.add(useLastButton);
        mainPanel.add(lastPanel, gbc);

        row++;
        gbc.gridx = 0; gbc.gridy = row;
        JLabel encryptedLabel = new JLabel("Зашифрованное сообщение:");
        encryptedLabel.setForeground(textColor);
        encryptedLabel.setFont(new Font("Arial", Font.BOLD, 12));
        mainPanel.add(encryptedLabel, gbc);

        gbc.gridx = 1;
        encryptedField = new JTextField(30);
        encryptedField.setBackground(fieldBg);
        encryptedField.setForeground(textColor);
        encryptedField.setBorder(new LineBorder(borderColor, 2, true));
        mainPanel.add(encryptedField, gbc);

        row++;
        gbc.gridx = 0; gbc.gridy = row; gbc.gridwidth = 2;
        JPanel controlPanel = new JPanel(new FlowLayout());
        controlPanel.setBackground(primaryBg);

        clearButton = new JButton("Очистить поля");
        clearButton.setBackground(buttonColor);
        clearButton.setForeground(textColor);
        clearButton.setFont(new Font("Arial", Font.BOLD, 12));
        clearButton.setBorder(new LineBorder(borderColor, 2, true));
        clearButton.setFocusPainted(false);
        clearButton.setCursor(new Cursor(Cursor.HAND_CURSOR));

        controlPanel.add(clearButton);
        mainPanel.add(controlPanel, gbc);

        row++;
        gbc.gridx = 0; gbc.gridy = row; gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;

        outputArea = new JTextArea(12, 50);
        outputArea.setEditable(false);
        outputArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        outputArea.setBackground(fieldBg);
        outputArea.setForeground(textColor);
        outputArea.setBorder(new LineBorder(borderColor, 2, true));

        JScrollPane scrollPane = new JScrollPane(outputArea);
        scrollPane.setBorder(new LineBorder(borderColor, 2, true));
        scrollPane.getViewport().setBackground(fieldBg);
        mainPanel.add(scrollPane, gbc);

        frame.add(mainPanel, BorderLayout.CENTER);
        addEventListeners();
        frame.setVisible(true);
    }

    private void addEventListeners() {
        generateButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                generateKeys();
            }
        });

        encryptButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                encryptMessage();
            }
        });

        decryptButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                decryptMessage();
            }
        });

        useLastButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (useLastYes.isSelected() && hasLastEncrypted) {
                    StringBuilder sb = new StringBuilder();
                    for (BigInteger num : lastEncrypted) {
                        sb.append(num.toString()).append(" ");
                    }
                    encryptedField.setText(sb.toString().trim());
                    outputArea.append("Используется последнее зашифрованное сообщение.\n");
                } else if (useLastYes.isSelected() && !hasLastEncrypted) {
                    outputArea.append("Нет последнего зашифрованного сообщения.\n");
                }
            }
        });

        clearButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                messageField.setText("");
                encryptedField.setText("");
                outputArea.setText("");
            }
        });
    }

    private boolean isCoprime(BigInteger a, BigInteger b) {
        return a.gcd(b).equals(BigInteger.ONE);
    }

    private void generateKeys() {
        try {
            p = new BigInteger(pField.getText().trim());
            q = new BigInteger(qField.getText().trim());

            n = p.multiply(q);
            phi = p.subtract(BigInteger.ONE).multiply(q.subtract(BigInteger.ONE));

            e = MIN_E;
            while (e.compareTo(phi) < 0 && !isCoprime(e, phi)) {
                e = e.add(BigInteger.ONE);
            }

            d = e.modInverse(phi);

            eField.setText(e.toString());
            nField.setText(n.toString());
            dField.setText(d.toString());

            outputArea.append("Ключи успешно сгенерированы:\n");
            outputArea.append("p = " + p + ", q = " + q + "\n");
            outputArea.append("Открытый ключ: (" + e + ", " + n + ")\n");
            outputArea.append("Закрытый ключ: (" + d + ", " + n + ")\n\n");

        } catch (Exception ex) {
            outputArea.append("Ошибка при генерации ключей: " + ex.getMessage() + "\n");
        }
    }

    private void encryptMessage() {
        if (e == null || n == null) {
            outputArea.append("Сначала сгенерируйте ключи!\n");
            return;
        }

        String message = messageField.getText().trim();
        if (message.isEmpty()) {
            outputArea.append("Введите сообщение для шифрования!\n");
            return;
        }

        try {
            lastEncrypted.clear();
            StringBuilder encryptedText = new StringBuilder();

            for (int i = 0; i < message.length(); i++) {
                char ch = message.charAt(i);
                BigInteger m = BigInteger.valueOf((int) ch);
                BigInteger c = m.modPow(e, n);
                lastEncrypted.add(c);
                encryptedText.append(c.toString()).append(" ");
            }

            hasLastEncrypted = true;
            String result = encryptedText.toString().trim();
            encryptedField.setText(result);
            outputArea.append("Зашифрованное сообщение: " + result + "\n");

        } catch (Exception ex) {
            outputArea.append("Ошибка при шифровании: " + ex.getMessage() + "\n");
        }
    }

    private void decryptMessage() {
        if (d == null || n == null) {
            outputArea.append("Сначала сгенерируйте ключи!\n");
            return;
        }

        String encryptedInput = encryptedField.getText().trim();
        if (encryptedInput.isEmpty()) {
            outputArea.append("Введите зашифрованное сообщение!\n");
            return;
        }

        try {
            String[] numbers = encryptedInput.split("[\\s,]+");
            StringBuilder decryptedText = new StringBuilder();

            for (String numStr : numbers) {
                if (numStr.isEmpty()) continue;
                BigInteger c = new BigInteger(numStr.trim());
                BigInteger m = c.modPow(d, n);
                decryptedText.append((char) m.intValue());
            }

            outputArea.append("Расшифрованное сообщение: " + decryptedText.toString() + "\n");

        } catch (Exception ex) {
            outputArea.append("Ошибка при расшифровании: " + ex.getMessage() + "\n");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new RSACipherGUI();
            }
        });
    }
}