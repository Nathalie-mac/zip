import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.math.BigInteger;
import java.security.SecureRandom;

public class DigitalSignatureApp extends JFrame {

    private JTextArea messageTextArea;
    private JTextField signatureRField;
    private JTextField signatureSField;
    private JTextArea resultArea;
    private JTextArea logArea;
    private JButton signButton;
    private JButton verifyButton;
    private JButton clearButton;
    private JCheckBox useLastCheckBox;

    private BigInteger p;
    private BigInteger q;
    private BigInteger a;
    private BigInteger x;
    private BigInteger y;
    private String lastMessage;
    private BigInteger lastR;
    private BigInteger lastS;

    public DigitalSignatureApp() {
        generateParameters();
        initUI();
        log("Параметры системы ЭЦП:");
        log("p = " + p.toString(16).toUpperCase());
        log("q = " + q.toString(16).toUpperCase());
        log("a = " + a.toString(16).toUpperCase());
        log("x (секретный ключ) = " + x.toString(16).toUpperCase());
        log("y (открытый ключ) = " + y.toString(16).toUpperCase());
        log("======================================");
    }

    private void generateParameters() {
        SecureRandom random = new SecureRandom();
        p = BigInteger.probablePrime(256, random);
        q = p.subtract(BigInteger.ONE).divide(BigInteger.valueOf(2));
        while (!q.isProbablePrime(100)) {
            p = BigInteger.probablePrime(256, random);
            q = p.subtract(BigInteger.ONE).divide(BigInteger.valueOf(2));
        }
        a = BigInteger.valueOf(2);
        while (!a.modPow(q, p).equals(BigInteger.ONE)) {
            a = a.add(BigInteger.ONE);
        }
        x = new BigInteger(q.bitLength() - 1, random);
        while (x.compareTo(BigInteger.ONE) <= 0 || x.compareTo(q) >= 0) {
            x = new BigInteger(q.bitLength() - 1, random);
        }
        y = a.modPow(x, p);
    }

    private BigInteger hashMessage(String message) {
        log("--- ЭТАП 1: ВЫЧИСЛЕНИЕ ХЭШ-ФУНКЦИИ ---");
        log("Исходное сообщение: \"" + message + "\"");

        byte[] messageBytes = message.getBytes();
        log("Байтовое представление: " + bytesToHex(messageBytes));

        int paddingLength = (2 - messageBytes.length % 2) % 2;
        byte[] paddedBytes = new byte[messageBytes.length + paddingLength];
        System.arraycopy(messageBytes, 0, paddedBytes, 0, messageBytes.length);

        if (paddingLength > 0) {
            log("Добавлено " + paddingLength + " байт выравнивания (нули)");
        }

        BigInteger checksum = BigInteger.ZERO;
        log("Начальное значение контрольной суммы: 0");

        for (int i = 0; i < paddedBytes.length; i += 2) {
            int block = ((paddedBytes[i] & 0xFF) << 8) | (paddedBytes[i + 1] & 0xFF);
            log("Блок " + (i/2 + 1) + ": " + Integer.toHexString(block).toUpperCase() +
                    " (дес: " + block + ")");

            checksum = checksum.xor(BigInteger.valueOf(block));
            log("  XOR -> " + checksum.toString(16).toUpperCase());

            long blockValue = checksum.longValue() & 0xFFFF;
            long rotated = (blockValue >>> 1) | ((blockValue & 1) << 15);
            checksum = BigInteger.valueOf(rotated);
            log("  Сдвиг вправо -> " + checksum.toString(16).toUpperCase());
        }

        BigInteger result = checksum.mod(q);
        if (result.equals(BigInteger.ZERO)) {
            log("Хэш по модулю q = 0 -> устанавливаем значение 1");
            log("Хэш h = 1");
            return BigInteger.ONE;
        }

        log("Итоговый хэш h = " + result.toString(16).toUpperCase() +
                " (дес: " + result + ")");
        log("------------------------------------------");
        return result;
    }

    private String bytesToHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder();
        for (byte b : bytes) {
            sb.append(String.format("%02X ", b));
        }
        return sb.toString();
    }

    private BigInteger[] generateSignature(String message) {
        log("=== ПРОЦЕСС ФОРМИРОВАНИЯ ЭЦП ===");
        SecureRandom random = new SecureRandom();

        BigInteger h = hashMessage(message);

        BigInteger k;
        BigInteger r;
        BigInteger s;
        int attempt = 0;

        do {
            attempt++;
            log("Попытка #" + attempt + ": генерация сеансового ключа k");

            k = new BigInteger(q.bitLength(), random);
            while (k.compareTo(BigInteger.ONE) <= 0 || k.compareTo(q) >= 0) {
                k = new BigInteger(q.bitLength(), random);
            }
            log("k = " + k.toString(16).toUpperCase() + " (дес: " + k + ")");

            log("Вычисление r = (a^k mod p) mod q");
            BigInteger ak = a.modPow(k, p);
            log("  a^k mod p = " + ak.toString(16).toUpperCase());
            r = ak.mod(q);
            log("  r = " + r.toString(16).toUpperCase());

            if (r.equals(BigInteger.ZERO)) {
                log("r = 0 -> повторяем генерацию k");
            }
        } while (r.equals(BigInteger.ZERO));

        log("r успешно сгенерировано");
        log("Вычисление s = (x*r + k*h) mod q");
        log("  x*r = " + x.multiply(r).toString(16).toUpperCase());
        log("  k*h = " + k.multiply(h).toString(16).toUpperCase());
        s = x.multiply(r).add(k.multiply(h)).mod(q);
        log("s = " + s.toString(16).toUpperCase());

        while (s.equals(BigInteger.ZERO)) {
            log("s = 0 -> повторяем процесс с новым k");
            do {
                k = new BigInteger(q.bitLength(), random);
                while (k.compareTo(BigInteger.ONE) <= 0 || k.compareTo(q) >= 0) {
                    k = new BigInteger(q.bitLength(), random);
                }
                r = a.modPow(k, p).mod(q);
            } while (r.equals(BigInteger.ZERO));

            s = x.multiply(r).add(k.multiply(h)).mod(q);
            log("Новое s = " + s.toString(16).toUpperCase());
        }

        log("ЭЦП успешно сформирована:");
        log("R = " + r.toString(16).toUpperCase());
        log("S = " + s.toString(16).toUpperCase());
        log("================================\n");

        return new BigInteger[]{r, s};
    }

    private boolean verifySignature(String message, BigInteger r, BigInteger s) {
        log("=== ПРОЦЕСС ПРОВЕРКИ ЭЦП ===");

        log("ШАГ 1: Проверка условий 0 < r < q и 0 < s < q");
        log("r = " + r.toString(16).toUpperCase());
        log("s = " + s.toString(16).toUpperCase());
        log("q = " + q.toString(16).toUpperCase());

        if (r.compareTo(BigInteger.ZERO) <= 0 || r.compareTo(q) >= 0) {
            log("УСЛОВИЕ НАРУШЕНО: r не в интервале (0, q)");
            return false;
        }
        if (s.compareTo(BigInteger.ZERO) <= 0 || s.compareTo(q) >= 0) {
            log("УСЛОВИЕ НАРУШЕНО: s не в интервале (0, q)");
            return false;
        }
        log("Условия выполнены");

        log("ШАГ 2: Вычисление хэша полученного сообщения");
        BigInteger h = hashMessage(message);

        log("ШАГ 3: Вычисление v = h^(q-2) mod q");
        BigInteger v = h.modPow(q.subtract(BigInteger.valueOf(2)), q);
        log("v = " + v.toString(16).toUpperCase());

        log("ШАГ 4: Вычисление z1 = s*v mod q");
        BigInteger z1 = s.multiply(v).mod(q);
        log("z1 = " + z1.toString(16).toUpperCase());

        log("ШАГ 5: Вычисление z2 = (q - r)*v mod q");
        BigInteger z2 = q.subtract(r).multiply(v).mod(q);
        log("z2 = " + z2.toString(16).toUpperCase());

        log("ШАГ 6: Вычисление u = (a^z1 * y^z2 mod p) mod q");
        BigInteger az1 = a.modPow(z1, p);
        log("  a^z1 mod p = " + az1.toString(16).toUpperCase());
        BigInteger yz2 = y.modPow(z2, p);
        log("  y^z2 mod p = " + yz2.toString(16).toUpperCase());
        BigInteger product = az1.multiply(yz2).mod(p);
        log("  произведение mod p = " + product.toString(16).toUpperCase());
        BigInteger u = product.mod(q);
        log("u = " + u.toString(16).toUpperCase());

        log("ШАГ 7: Сравнение u и r");
        log("u = " + u.toString(16).toUpperCase());
        log("r = " + r.toString(16).toUpperCase());

        boolean isValid = u.equals(r);
        log("РЕЗУЛЬТАТ: " + (isValid ? "ПОДПИСЬ ПРИНЯТА" : "ПОДПИСЬ ОТВЕРГНУТА"));
        log("================================\n");

        return isValid;
    }

    private void log(String message) {
        logArea.append(message + "\n");
        logArea.setCaretPosition(logArea.getDocument().getLength());
    }

    private void initUI() {
        setTitle("Лабораторная работа №5: ЭЦП ГОСТ Р34.10-94");
        setSize(1100, 850);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        Color pastelPink = new Color(255, 228, 235);
        Color lightPink = new Color(255, 245, 250);
        Color darkPink = new Color(255, 182, 193);
        Color borderPink = new Color(255, 160, 180);

        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBackground(pastelPink);
        mainPanel.setBorder(new EmptyBorder(10, 10, 10, 10));

        JPanel inputPanel = new JPanel(new GridBagLayout());
        inputPanel.setBackground(lightPink);
        inputPanel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(borderPink, 2),
                " Входные данные ",
                TitledBorder.LEFT,
                TitledBorder.TOP,
                new Font("Arial", Font.BOLD, 14),
                darkPink
        ));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.WEST;
        JLabel messageLabel = new JLabel("Сообщение M:");
        messageLabel.setFont(new Font("Arial", Font.BOLD, 12));
        inputPanel.add(messageLabel, gbc);

        gbc.gridx = 1;
        gbc.weightx = 1.0;
        messageTextArea = new JTextArea(3, 50);
        messageTextArea.setLineWrap(true);
        messageTextArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        messageTextArea.setBorder(BorderFactory.createLineBorder(borderPink));
        JScrollPane scrollPane = new JScrollPane(messageTextArea);
        inputPanel.add(scrollPane, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.weightx = 0;
        JLabel rLabel = new JLabel("Подпись R (16-рич.):");
        rLabel.setFont(new Font("Arial", Font.BOLD, 12));
        inputPanel.add(rLabel, gbc);

        gbc.gridx = 1;
        signatureRField = new JTextField(50);
        signatureRField.setFont(new Font("Monospaced", Font.PLAIN, 12));
        signatureRField.setBorder(BorderFactory.createLineBorder(borderPink));
        inputPanel.add(signatureRField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        JLabel sLabel = new JLabel("Подпись S (16-рич.):");
        sLabel.setFont(new Font("Arial", Font.BOLD, 12));
        inputPanel.add(sLabel, gbc);

        gbc.gridx = 1;
        signatureSField = new JTextField(50);
        signatureSField.setFont(new Font("Monospaced", Font.PLAIN, 12));
        signatureSField.setBorder(BorderFactory.createLineBorder(borderPink));
        inputPanel.add(signatureSField, gbc);

        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setBackground(pastelPink);
        topPanel.add(inputPanel, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        buttonPanel.setBackground(lightPink);
        buttonPanel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(borderPink, 2),
                " Управление ",
                TitledBorder.LEFT,
                TitledBorder.TOP,
                new Font("Arial", Font.BOLD, 14),
                darkPink
        ));

        signButton = new JButton("ПОДПИСАТЬ");
        signButton.setBackground(darkPink);
        signButton.setForeground(Color.WHITE);
        signButton.setFont(new Font("Arial", Font.BOLD, 14));
        signButton.setFocusPainted(false);
        signButton.setPreferredSize(new Dimension(150, 40));

        verifyButton = new JButton("ПРОВЕРИТЬ");
        verifyButton.setBackground(darkPink);
        verifyButton.setForeground(Color.WHITE);
        verifyButton.setFont(new Font("Arial", Font.BOLD, 14));
        verifyButton.setFocusPainted(false);
        verifyButton.setPreferredSize(new Dimension(150, 40));

        clearButton = new JButton("ОЧИСТИТЬ");
        clearButton.setBackground(darkPink);
        clearButton.setForeground(Color.WHITE);
        clearButton.setFont(new Font("Arial", Font.BOLD, 14));
        clearButton.setFocusPainted(false);
        clearButton.setPreferredSize(new Dimension(150, 40));

        useLastCheckBox = new JCheckBox("Использовать последнюю подпись");
        useLastCheckBox.setBackground(lightPink);
        useLastCheckBox.setFont(new Font("Arial", Font.PLAIN, 12));

        buttonPanel.add(signButton);
        buttonPanel.add(verifyButton);
        buttonPanel.add(clearButton);
        buttonPanel.add(useLastCheckBox);

        topPanel.add(buttonPanel, BorderLayout.SOUTH);

        JPanel outputPanel = new JPanel(new GridLayout(2, 1, 10, 10));
        outputPanel.setBackground(lightPink);
        outputPanel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(borderPink, 2),
                " Результаты и пошаговый лог выполнения ",
                TitledBorder.LEFT,
                TitledBorder.TOP,
                new Font("Arial", Font.BOLD, 14),
                darkPink
        ));

        resultArea = new JTextArea(4, 60);
        resultArea.setEditable(false);
        resultArea.setFont(new Font("Arial", Font.BOLD, 14));
        resultArea.setBackground(Color.WHITE);
        JScrollPane resultScrollPane = new JScrollPane(resultArea);
        resultScrollPane.setBorder(BorderFactory.createLineBorder(borderPink));

        logArea = new JTextArea(18, 60);
        logArea.setEditable(false);
        logArea.setFont(new Font("Monospaced", Font.PLAIN, 11));
        logArea.setBackground(Color.WHITE);
        JScrollPane logScrollPane = new JScrollPane(logArea);
        logScrollPane.setBorder(BorderFactory.createLineBorder(borderPink));

        outputPanel.add(resultScrollPane);
        outputPanel.add(logScrollPane);

        mainPanel.add(topPanel, BorderLayout.NORTH);
        mainPanel.add(outputPanel, BorderLayout.CENTER);

        add(mainPanel);

        signButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String message = messageTextArea.getText().trim();
                if (message.isEmpty()) {
                    resultArea.setText("ОШИБКА: Введите сообщение для подписи");
                    return;
                }
                try {
                    resultArea.setText(">>> ФОРМИРОВАНИЕ ПОДПИСИ...");
                    log("=========================================");
                    log("НАЧАЛО ФОРМИРОВАНИЯ ПОДПИСИ");
                    log("Сообщение: \"" + message + "\"");

                    BigInteger[] signature = generateSignature(message);
                    lastMessage = message;
                    lastR = signature[0];
                    lastS = signature[1];

                    String rHex = signature[0].toString(16).toUpperCase();
                    String sHex = signature[1].toString(16).toUpperCase();

                    signatureRField.setText(rHex);
                    signatureSField.setText(sHex);

                    resultArea.setText("ПОДПИСЬ УСПЕШНО СОЗДАНА\nR = " + rHex + "\nS = " + sHex);
                    log("ПОДПИСЬ СОХРАНЕНА");
                } catch (Exception ex) {
                    resultArea.setText("ОШИБКА: " + ex.getMessage());
                }
            }
        });

        verifyButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String message = messageTextArea.getText().trim();
                String rText, sText;

                if (useLastCheckBox.isSelected() && lastMessage != null && lastR != null && lastS != null) {
                    message = lastMessage;
                    rText = lastR.toString(16).toUpperCase();
                    sText = lastS.toString(16).toUpperCase();
                    messageTextArea.setText(message);
                    signatureRField.setText(rText);
                    signatureSField.setText(sText);
                    log("Используется последняя подпись");
                } else {
                    rText = signatureRField.getText().trim();
                    sText = signatureSField.getText().trim();
                }

                if (message.isEmpty() || rText.isEmpty() || sText.isEmpty()) {
                    resultArea.setText("ОШИБКА: Заполните все поля");
                    return;
                }

                try {
                    resultArea.setText(">>> ПРОВЕРКА ПОДПИСИ...");
                    log("=========================================");
                    log("НАЧАЛО ПРОВЕРКИ ПОДПИСИ");
                    log("Сообщение: \"" + message + "\"");
                    log("R = " + rText);
                    log("S = " + sText);

                    BigInteger r = new BigInteger(rText, 16);
                    BigInteger s = new BigInteger(sText, 16);

                    boolean isValid = verifySignature(message, r, s);

                    if (isValid) {
                        resultArea.setText("РЕЗУЛЬТАТ: ПОДПИСЬ ПРИНЯТА");
                    } else {
                        resultArea.setText("РЕЗУЛЬТАТ: ПОДПИСЬ ОТВЕРГНУТА");
                    }
                } catch (NumberFormatException ex) {
                    resultArea.setText("ОШИБКА: Неверный формат (ожидается 16-ричное число)");
                }
            }
        });

        clearButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                messageTextArea.setText("");
                signatureRField.setText("");
                signatureSField.setText("");
                resultArea.setText("");
                logArea.setText("");
                useLastCheckBox.setSelected(false);
                log("=== НОВАЯ СЕССИЯ ===");
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
                } catch (Exception e) {
                    e.printStackTrace();
                }
                new DigitalSignatureApp().setVisible(true);
            }
        });
    }
}